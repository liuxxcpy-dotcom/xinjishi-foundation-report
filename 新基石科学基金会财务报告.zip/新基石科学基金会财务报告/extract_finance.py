#!/usr/bin/env python3
"""提取新基石科学基金会2022-2025年审计报告中的财务数据"""

import pdfplumber
import json
import sys

pdf_files = {
    "2025": "/Users/xx/Desktop/800基金会/【档案】深圳新基石科学基金会档案/4-CW财务管理 by 朋阳/404财务报告（审计报告）/【汇总】深圳新基石科学基金会历年年度工作报告和审计报告（2022-2025）/20260324新基石科学基金会2025 年度财务报表及审计报告-深圳-审计-普华永道中天深审字(2026)第0053号.pdf",
    "2024": "/Users/xx/Desktop/800基金会/【档案】深圳新基石科学基金会档案/4-CW财务管理 by 朋阳/404财务报告（审计报告）/【汇总】深圳新基石科学基金会历年年度工作报告和审计报告（2022-2025）/20250327新基石科学基金会2024年度财务报表及审计报告-深圳-审计-普华永道中天深审字(2025)第0048号.pdf",
    "2023": "/Users/xx/Desktop/800基金会/【档案】深圳新基石科学基金会档案/4-CW财务管理 by 朋阳/404财务报告（审计报告）/【汇总】深圳新基石科学基金会历年年度工作报告和审计报告（2022-2025）/20240327深圳新基石科学基金会2023年度财务报表及审计报告-深圳-审计-普华永道中天深审字(2024)第0490号.pdf",
    "2022": "/Users/xx/Desktop/800基金会/【档案】深圳新基石科学基金会档案/4-CW财务管理 by 朋阳/404财务报告（审计报告）/【汇总】深圳新基石科学基金会历年年度工作报告和审计报告（2022-2025）/20230520深圳新基石科学基金会2022年度审计报告扫描件 -永柘会计师事务所-已赋码.pdf",
}

def extract_financial_data(pdf_path, year):
    """提取PDF中的财务数据"""
    result = {"year": year, "text_content": [], "tables": []}
    
    try:
        with pdfplumber.open(pdf_path) as pdf:
            print(f"\n{'='*60}")
            print(f"处理 {year} 年度报告: {len(pdf.pages)} 页")
            print(f"{'='*60}")
            
            # 提取所有页面的文本和表格
            for i, page in enumerate(pdf.pages):
                text = page.extract_text()
                if text:
                    result["text_content"].append({"page": i+1, "text": text})
                
                tables = page.extract_tables()
                for j, table in enumerate(tables):
                    if table:
                        result["tables"].append({"page": i+1, "table_idx": j+1, "data": table})
            
            # 打印前几页的文本用于分析结构
            print(f"\n--- {year} 年度报告 文本内容预览 ---")
            for tc in result["text_content"][:8]:
                print(f"\n[第{tc['page']}页]")
                print(tc['text'][:2000] if len(tc['text']) > 2000 else tc['text'])
            
            # 打印所有表格
            print(f"\n--- {year} 年度报告 表格内容 (共{len(result['tables'])}个表格) ---")
            for t in result["tables"]:
                print(f"\n[第{t['page']}页-表格{t['table_idx']}]")
                for row in t['data']:
                    print(row)
                    
    except Exception as e:
        print(f"处理 {year} 年度报告时出错: {e}")
        result["error"] = str(e)
    
    return result

# 提取所有年度数据
all_data = {}
for year, path in pdf_files.items():
    all_data[year] = extract_financial_data(path, year)

# 保存完整提取结果
output_path = "/Users/xx/WorkBuddy/20260409095450/financial_data_extracted.json"
with open(output_path, "w", encoding="utf-8") as f:
    json.dump(all_data, f, ensure_ascii=False, indent=2)

print(f"\n\n数据已保存到: {output_path}")
