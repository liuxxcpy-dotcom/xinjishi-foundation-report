#!/usr/bin/env python3
"""使用 PaddleOCR 提取扫描件 PDF 中的财务数据"""

import json
import os
import sys
import numpy as np
from PIL import Image
import io
from pypdfium2 import PdfDocument
from paddleocr import PaddleOCR

# 初始化 OCR（只初始化一次）
print("初始化 PaddleOCR...")
ocr = PaddleOCR(lang='ch')

pdf_files = {
    "2025": "/Users/xx/Desktop/800基金会/【档案】深圳新基石科学基金会档案/4-CW财务管理 by 朋阳/404财务报告（审计报告）/【汇总】深圳新基石科学基金会历年年度工作报告和审计报告（2022-2025）/20260324新基石科学基金会2025 年度财务报表及审计报告-深圳-审计-普华永道中天深审字(2026)第0053号.pdf",
    "2024": "/Users/xx/Desktop/800基金会/【档案】深圳新基石科学基金会档案/4-CW财务管理 by 朋阳/404财务报告（审计报告）/【汇总】深圳新基石科学基金会历年年度工作报告和审计报告（2022-2025）/20250327新基石科学基金会2024年度财务报表及审计报告-深圳-审计-普华永道中天深审字(2025)第0048号.pdf",
    "2023": "/Users/xx/Desktop/800基金会/【档案】深圳新基石科学基金会档案/4-CW财务管理 by 朋阳/404财务报告（审计报告）/【汇总】深圳新基石科学基金会历年年度工作报告和审计报告（2022-2025）/20240327深圳新基石科学基金会2023年度财务报表及审计报告-深圳-审计-普华永道中天深审字(2024)第0490号.pdf",
    "2022": "/Users/xx/Desktop/800基金会/【档案】深圳新基石科学基金会档案/4-CW财务管理 by 朋阳/404财务报告（审计报告）/【汇总】深圳新基石科学基金会历年年度工作报告和审计报告（2022-2025）/20230520深圳新基石科学基金会2022年度审计报告扫描件 -永柘会计师事务所-已赋码.pdf",
}

def ocr_pdf(pdf_path, year):
    """对PDF进行OCR识别"""
    print(f"\n{'='*60}")
    print(f"处理 {year} 年度报告: {pdf_path}")
    print(f"{'='*60}")
    
    # 使用pypdfium2转换PDF为图片（不需要poppler）
    print("  正在转换PDF为图片...")
    pdf = PdfDocument(pdf_path)
    total_pages = len(pdf)
    print(f"  共 {total_pages} 页")
    
    all_text = []
    for i in range(total_pages):
        page = pdf[i]
        # 渲染为位图，200dpi
        bitmap = page.render(scale=200 / 72)  # scale = dpi / 72
        pil_image = bitmap.to_pil()
        # 转换为numpy数组（新版PaddleOCR要求）
        img_array = np.array(pil_image)
        
        print(f"  OCR识别 第 {i+1}/{total_pages} 页...", end=" ", flush=True)
        result = ocr.predict(img_array)
        
        page_text = []
        # 新版PaddleOCR返回格式
        if result:
            for item in result:
                # 检查返回结构并提取文字
                if hasattr(item, 'rec_texts'):
                    page_text.extend(item.rec_texts)
                elif isinstance(item, dict):
                    if 'rec_texts' in item:
                        page_text.extend(item['rec_texts'])
                    elif 'text' in item:
                        page_text.append(item['text'])
                elif isinstance(item, list) and len(item) >= 2:
                    # 旧格式兼容: [[bbox, (text, conf)], ...]
                    page_text.append(item[1][0])
                elif isinstance(item, str):
                    page_text.append(item)
        
        page_str = "\n".join(page_text)
        all_text.append({"page": i+1, "text": page_str})
        print(f"完成 ({len(page_text)} 行)")
    
    return all_text

# 处理所有文件
all_data = {}
for year, path in pdf_files.items():
    all_data[year] = {
        "year": year,
        "pages": ocr_pdf(path, year)
    }

# 保存结果
output_path = "/Users/xx/WorkBuddy/20260409095450/ocr_financial_data.json"
with open(output_path, "w", encoding="utf-8") as f:
    json.dump(all_data, f, ensure_ascii=False, indent=2)

print(f"\n\n✅ OCR完成！数据已保存到: {output_path}")

# 打印每个年份的关键页面内容用于分析
for year, data in all_data.items():
    print(f"\n\n{'#'*70}")
    print(f"# {year} 年度报告 OCR 结果")
    print(f"{'#'*70}")
    for p in data["pages"]:
        print(f"\n--- 第{p['page']}页 ---")
        print(p['text'][:3000] if p['text'] else '(无文字)')
